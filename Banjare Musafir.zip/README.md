
  # Banjare Musafir

  This is a code bundle for Banjare Musafir. The original project is available at https://www.figma.com/design/WzjFIMBhMAsPOx6bd9NJhw/Banjare-Musafir.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  